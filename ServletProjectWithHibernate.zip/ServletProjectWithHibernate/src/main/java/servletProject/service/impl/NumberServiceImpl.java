package servletProject.service.impl;

import servletProject.service.NumberService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class NumberServiceImpl implements NumberService {
    @Override
    public void getAllNumbers() {

    }


    @Override
    public void addNewNumber(HttpServletRequest request, HttpServletResponse response) {

    }

    @Override
    public void updateNumber(HttpServletRequest request, HttpServletResponse response) {

    }

    @Override
    public void deleteNumberById(Integer id) {

    }
}
