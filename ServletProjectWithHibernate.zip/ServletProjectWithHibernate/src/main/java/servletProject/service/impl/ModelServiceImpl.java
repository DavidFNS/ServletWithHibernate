package servletProject.service.impl;

import servletProject.service.ModelService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ModelServiceImpl implements ModelService {
    @Override
    public void getAllModels() {

    }


    @Override
    public void addNewModel(HttpServletRequest request, HttpServletResponse response) {

    }

    @Override
    public void updateModel(HttpServletRequest request, HttpServletResponse response) {

    }

    @Override
    public void deleteModelById(Integer id) {

    }
}
