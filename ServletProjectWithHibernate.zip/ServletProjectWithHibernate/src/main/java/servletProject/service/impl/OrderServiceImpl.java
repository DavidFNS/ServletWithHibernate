package servletProject.service.impl;

import servletProject.service.OrderService;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class OrderServiceImpl implements OrderService {
    @Override
    public void getAllOrders() {

    }

    @Override
    public void addNewOrder(HttpServletRequest request, HttpServletResponse response) {

    }

    @Override
    public void updateOrder(HttpServletRequest request, HttpServletResponse response) {

    }

    @Override
    public void deleteOrderById(Integer id) {

    }
}
